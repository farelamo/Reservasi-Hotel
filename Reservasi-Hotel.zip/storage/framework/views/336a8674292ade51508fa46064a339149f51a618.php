

<?php $__env->startSection('content'); ?>
    <section id="detail" class="detail-section-padding">
        <div class="container mt-5">
            <div class="row">
                <div class="col-10">
                    <img src="<?php echo e(Storage::disk('local')->exists("public/states/{$state->name}")
                    ? Storage::url('public/states/' . $state->name . "/{$state->stateImages()->first()->image}")
                    : asset('user/images/produk1.png')); ?>" alt="" height="100%" width="98%">
                </div>
                <div class="col-2">
                    <?php $state->stateImages->shift(); ?>
                    <?php $__currentLoopData = $state->stateImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stateImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row <?php if($state->stateImages->last()->id != $stateImage->id): ?> mb-5 <?php endif; ?>">
                            <img src="<?php echo e(Storage::disk('local')->exists("public/states/{$state->name}")
                                ? Storage::url('public/states/' . $state->name . "/{$stateImage->image}")
                                : asset('user/images/kamar2.png')); ?>" alt="" height="150">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="row">
                <section class="mt-5">
                    <h2><?php echo e($state->name); ?></h2>
                    <div class="row">
                        <div class="col-4">
                            <div class="row">
                                <div class="col">
                                    <p>
                                        <i class="fas fa-bed"></i>
                                        Jumlah Bed : <?php echo e($state->bedroom); ?>

                                    </p>
                                </div>
                                <div class="col">
                                    <p>
                                        <i class="fas fa-building"></i>
                                        Jumlah Room : <?php echo e($state->room); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-8 d-flex justify-content-end">
                            <h3 class="text-success fw-bold">
                                Rp. <?php echo e(number_format($state->price, 0, '', '.')); ?>

                            </h3>
                        </div>
                    </div>
                    <p>
                        <?php echo e($state->facilities); ?>

                    </p>
                </section>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FARIZ COWORKSPACE\Bantu\dinda\Nyar\TA admin(3)\TA admin\Reservasi-Hotel\resources\views/user/detail.blade.php ENDPATH**/ ?>
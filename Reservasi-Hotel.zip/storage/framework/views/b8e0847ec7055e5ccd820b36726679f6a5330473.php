

<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="https://unpkg.com/@jarstone/dselect/dist/css/dselect.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card mb-4">
        <h5 class="card-header">Edit Investor</h5>
        <div class="card-body">
            <form action="/receptionist/investor/<?php echo e($investor->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <div class="col mb-3">
                    <label for="investor" class="form-label">Nama Investor</label>
                    <input type="text" class="form-control" id="investor" name="company_name"
                        placeholder="Nama" value="<?php echo e(old('company_name') ?? $investor->company_name); ?>" />
                    <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">*<?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col mb-3">
                    <label for="negara" class="form-label">Negara Investor</label>
                    <input type="text" class="form-control" id="negara" name="country"
                        placeholder="Negara" value="<?php echo e(old('country') ?? $investor->country); ?>" />
                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">*<?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col mb-3">
                    <label for="telp" class="form-label">Nomor Telepon Investor</label>
                    <input type="number" class="form-control" id="telp" name="phone"
                        placeholder="Nomor telepon" value="<?php echo e(old('phone') ?? $investor->phone); ?>" />
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">*<?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-danger">Edit Data</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA admin\Reservasi-Hotel\resources\views/receptionist/investor/edit.blade.php ENDPATH**/ ?>
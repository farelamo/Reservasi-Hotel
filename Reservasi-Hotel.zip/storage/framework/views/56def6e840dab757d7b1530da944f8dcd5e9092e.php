

<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="https://unpkg.com/@jarstone/dselect/dist/css/dselect.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card mb-4">
        <h5 class="card-header">Vaccine Karyawan</h5>
        <div class="card-body">
            <form action="/receptionist/investor/<?php echo e($investor_id); ?>/employee/<?php echo e($employee->id); ?>/vaccine" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="col mb-3">
                    <label for="vaccine1" class="form-label">
                        Vaccine 1
                        <span class="text-danger">*Edit Jika perlu</span>
                    </label>
                    <input class="form-control" type="file" id="vaccine1" placeholder="<?php echo e($employee->vaccine1); ?>" name="vaccine1"/>
                    <?php $__errorArgs = ['vaccine1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">*<?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col mb-3">
                    <label for="vaccine2" class="form-label">
                        Vaccine 2
                        <span class="text-danger">*Edit Jika perlu</span>
                    </label>
                    <input class="form-control" type="file" id="vaccine2" placeholder="<?php echo e($employee->vaccine2); ?>" name="vaccine2"/>
                    <?php $__errorArgs = ['vaccine2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">*<?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col mb-3">
                    <label for="vaccine3" class="form-label">
                        Vaccine 3
                        <span class="text-danger">*Edit Jika perlu</span>
                    </label>
                    <input class="form-control" type="file" id="vaccine3" placeholder="<?php echo e($employee->vaccine3); ?>" name="vaccine3"/>
                    <?php $__errorArgs = ['vaccine3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">*<?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-danger">Edit Data</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA admin\Reservasi-Hotel\resources\views/receptionist/employee/vaccine.blade.php ENDPATH**/ ?>
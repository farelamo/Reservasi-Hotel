<?php $__env->startPush('head'); ?>
    <style>
        .page-item.active .page-link,
        .page-item.active .page-link:hover,
        .page-item.active .page-link:focus,
        .pagination li.active>a:not(.page-link),
        .pagination li.active>a:not(.page-link):hover,
        .pagination li.active>a:not(.page-link):focus {
            border-color: #198754;
            background-color: #198754;
            color: #ffff;
            box-shadow: 0 0.125rem 0.25rem #198754;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="card p-3">
            <form action="" method="get">
                <div class="d-flex gap-5">
                    <div class="col-3">
                        <label for="">Nama Tempat</label>
                        <input type="text" class="form-control" name="nama_tempat" 
                                placeholder="Mau nginep di hotel mana?" value="<?php echo e(old('nama_tempat')); ?>"
                        >
                    </div>
                    <div class="col-3">
                        <label for="">Harga Dari</label>
                        <input type="number" class="form-control" name="start" value="<?php echo e(old('start')); ?>">
                    </div>
                    <div class="col-3">
                        <label for="">Harga Sampai</label>
                        <input type="number" class="form-control" name="end" value="<?php echo e(old('end')); ?>">
                    </div>
                    
                    <div class="col-3">
                        <button type="submit" style="margin-top: 1.32rem;" class="btn btn-success text-white">
                            Pencarian
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="container mb-5">
        <div class="row">

            <!-- Aside -->
            
            

            

            

            
            

            <!-- Main -->
            <?php $__empty_1 = true; $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card mb-3">
                    <div class="row p-3">
                        <div class="col-4">
                            <img style="height: 12rem; width: 20rem"
                                src="<?php echo e(Storage::disk('local')->exists("public/states/{$state->name}")
                                    ? Storage::url('public/states/' . $state->name . "/{$state->stateImages()->first()->image}")
                                    : asset('user/images/produk1.png')); ?>"
                                class="img-fluid" alt="">
                        </div>
                        <div class="col-4">
                            <div class="row">
                                <h3><?php echo e($state->name); ?></h3>
                            </div>
                            <div class="row">
                                <p class="text-secondary">
                                    Jumlah Kamar :
                                    <span class="text-secondary"><?php echo e($state->bedroom); ?></span>
                                </p>
                                <p class="text-secondary" style="margin-top: -1rem">
                                    Jumlah Ruangan :
                                    <span class="text-secondary"><?php echo e($state->room); ?></span>
                                </p>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="row mt-4">
                                <div class="d-flex justify-content-end">
                                    <h3 class="text-success fw-bold">
                                        Rp. <?php echo e(number_format($state->price, 0, '', '.')); ?>

                                    </h3>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span style="color:grey;">
                                        /kamar/malam(+PPN)
                                    </span>
                                </div>
                            </div>
                            <a href="/cek/<?php echo e($state->id); ?>" style="text-decoration: none">
                                <div class="row" style="margin-top: 4rem">
                                    <button class="btn btn-success text-white">
                                        Lihat Tempat
                                    </button>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h1>Data Tidak Ditemukan</h1>
            <?php endif; ?>

            <?php echo $states->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA admin\Reservasi-Hotel\resources\views/user/cek_ketersediaan.blade.php ENDPATH**/ ?>
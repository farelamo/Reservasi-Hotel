

<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="https://unpkg.com/@jarstone/dselect/dist/css/dselect.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card mb-4">
        <h5 class="card-header">Tambah State</h5>
        <div class="card-body">
            <form action="/admin/state/<?php echo e($state->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col mb-3">
                        <label for="start" class="form-label">Nama State</label>
                        <input type="text" class="form-control" id="start" name="name" placeholder="Nama state"
                            value="<?php echo e(old('start') ?? $state->name); ?>" />
                        <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col mb-3">
                        <label for="price" class="form-label">Harga Sewa</label>
                        <input type="text" class="form-control" id="price" name="price" placeholder="Harga Sewa"
                            value="<?php echo e(old('price') ?? $state->price); ?>" />
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                        <label for="room" class="form-label">Jumlah Ruangan</label>
                        <input type="number" class="form-control" id="room" name="room" placeholder="Jumlah ruangan"
                            value="<?php echo e(old('room') ?? $state->room); ?>" />
                        <?php $__errorArgs = ['room'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col mb-3">
                        <label for="bedroom" class="form-label">
                            Jumlah kamar 
                            <span class="text-danger">*dalam 1 ruangan</span>
                        </label>
                        <input type="number" class="form-control" id="bedroom" name="bedroom" placeholder="Jumlah kamar"
                            value="<?php echo e(old('bedroom') ?? $state->bedroom); ?>" />
                        <?php $__errorArgs = ['bedroom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="facilities" class="form-label">Fasilitas</label>
                    <textarea class="form-control" id="facilities" name="facilities" placeholder="Fasilitas"><?php echo e(old('facilities') ?? $state->facilities); ?></textarea>
                    <?php $__errorArgs = ['facilities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger">*<?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-danger">Edit Data</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA admin\Reservasi-Hotel\resources\views/admin/state/edit.blade.php ENDPATH**/ ?>
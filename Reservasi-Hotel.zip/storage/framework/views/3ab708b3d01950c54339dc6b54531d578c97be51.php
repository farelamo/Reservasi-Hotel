<!doctype html>
  <html lang="en">
  <head>
    <?php echo $__env->make('user.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('head'); ?>
  </head>
  <body>

      <?php echo $__env->make('user.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->yieldContent('content'); ?>

      <?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </body>
</html>
<?php /**PATH D:\FARIZ COWORKSPACE\Bantu\dinda\Nyar\TA admin(3)\TA admin\Reservasi-Hotel\resources\views/user/master.blade.php ENDPATH**/ ?>
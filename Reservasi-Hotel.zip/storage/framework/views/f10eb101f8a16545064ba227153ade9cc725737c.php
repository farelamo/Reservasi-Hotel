<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BINTAN</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script src="https://kit.fontawesome.com/348c676099.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="<?php echo e(asset('user/style.css')); ?>">
<link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/logo.png')); ?>" />
<?php /**PATH D:\TA admin\Reservasi-Hotel\resources\views/user/layouts/head.blade.php ENDPATH**/ ?>
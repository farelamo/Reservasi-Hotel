

<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="https://unpkg.com/@jarstone/dselect/dist/css/dselect.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card mb-4">
        <h5 class="card-header">Edit Gambar State</h5>
        <div class="card-body">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <form action="/admin/state/<?php echo e($state->id); ?>/image" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="col mb-3">
                    <label for="images" class="form-label">
                        Upload Gambar State (multiple upload)
                        <span class="text-danger">*Edit Jika perlu</span>
                    </label>
                    <input class="form-control" type="file" id="images" name="images[]" multiple/>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-danger">Edit Data</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(('template/assets/js/form-basic-inputs.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA admin\Reservasi-Hotel\resources\views/admin/state/image.blade.php ENDPATH**/ ?>
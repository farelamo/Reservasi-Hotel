<footer id="tentangkami" class="container mb-5">
    <img src="{{ asset('user/images/logo.png') }}" class="img-fluid" width="100" alt="">
    <br>
    <div class="d-flex gap-3 my-4">
        <a href="#">Beranda</a>
        <a href="#">Villa</a>
        <a href="#">Promo</a>
        <a href="#">Fasilitas</a>
        <a href="#">Tentang Kami</a>
    </div>

    <div class="d-flex justify-content-between">
        <span>2023</span>
        <span>
            <div class="d-flex gap-3">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
                <a href="#">Cookies Settings</a>
            </div>
        </span>
    </div>
</footer>